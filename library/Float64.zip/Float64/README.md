# Float64
Double precision 64-bit floating point library for Arduino.
This is a simple port of the Berkeley SoftFloat library.
